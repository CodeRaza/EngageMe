import flask_praetorian
guard = flask_praetorian.Praetorian()